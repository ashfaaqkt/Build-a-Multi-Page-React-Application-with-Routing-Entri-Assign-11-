import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import Home from './pages/Home.jsx';
import About from './pages/About.jsx';
import Users from './pages/Users.jsx';
import UserDetail from './pages/UserDetail.jsx';

function App() {
  return (
    <div className="app">
      <Navbar />
      <main className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/users" element={<Users />} />
          <Route path="/users/:id" element={<UserDetail />} />
        </Routes>
      </main>
      <footer className="footer">
        <p>Created by Ashfaaq Feroz Muhammad</p>
        <p>Entri Assignment (11)</p>
      </footer>
    </div>
  );
}

export default App;
