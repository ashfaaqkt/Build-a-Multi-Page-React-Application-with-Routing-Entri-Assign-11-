// Mock user data for the Users and User Detail pages.
export const users = [
  { id: 1, name: 'John Doe', email: 'john@entri.com', role: 'Frontend Learner' },
  { id: 2, name: 'Jane Smith', email: 'jane@entri.com', role: 'UI Explorer' },
  { id: 3, name: 'Alex Brown', email: 'alex@entri.com', role: 'React Beginner' },
  { id: 4, name: 'Ashfaaq Feroz Muhammad', email: 'ashfaaq@entri.com', role: 'React Learner' }
];
