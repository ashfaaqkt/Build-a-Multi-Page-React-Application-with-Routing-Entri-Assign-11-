import { Link } from 'react-router-dom';

function About() {
  return (
    <section className="page">
      <h2>About This App</h2>
      <p>
        The goal of this project is to practice routing with React Router and
        build a clean multi-page layout for educational learning.
      </p>
      <p>
        You can explore the Users list and open each user detail page using
        dynamic routes.
      </p>
      <Link className="btn" to="/">
        Back to Home
      </Link>
    </section>
  );
}

export default About;
