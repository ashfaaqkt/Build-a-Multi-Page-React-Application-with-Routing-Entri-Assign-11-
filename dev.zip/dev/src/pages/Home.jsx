import { Link } from 'react-router-dom';

function Home() {
  return (
    <section className="page">
      <div className="hero">
        <h1>Welcome to the Multi-Page React App</h1>
        <p>
          This simple project demonstrates routing, navigation, and basic UI
          components using React Router.
        </p>
        <div className="button-row">
          <Link className="btn" to="/about">
            Learn About
          </Link>
          <Link className="btn btn-outline" to="/users">
            View Users
          </Link>
        </div>
      </div>
    </section>
  );
}

export default Home;
