import { Link, useParams } from 'react-router-dom';
import { users } from '../data/users.js';

function UserDetail() {
  const { id } = useParams();
  const user = users.find((item) => item.id === Number(id));

  if (!user) {
    return (
      <section className="page">
        <h2>User Not Found</h2>
        <p>We could not find a user with that id.</p>
        <Link className="btn" to="/users">
          Go Back
        </Link>
      </section>
    );
  }

  return (
    <section className="page">
      <h2>User Detail</h2>
      <div className="detail-card">
        <h3>{user.name}</h3>
        <p>Email: {user.email}</p>
        <p>Role: {user.role}</p>
      </div>
      <Link className="btn" to="/users">
        Go Back
      </Link>
    </section>
  );
}

export default UserDetail;
