import { Link } from 'react-router-dom';
import { users } from '../data/users.js';

function Users() {
  return (
    <section className="page">
      <h2>Users List</h2>
      <p>Click a user to view their detail page.</p>
      <div className="card-grid">
        {users.map((user) => (
          <Link key={user.id} className="card" to={`/users/${user.id}`}>
            <h3>{user.name}</h3>
            <p>{user.email}</p>
            <span className="tag">{user.role}</span>
          </Link>
        ))}
      </div>
    </section>
  );
}

export default Users;
