import { NavLink } from 'react-router-dom';

function Navbar() {
  return (
    <header className="navbar">
      <div className="brand">Multi-Page React App</div>
      <nav className="nav-links">
        <NavLink to="/" end className="nav-link">
          Home
        </NavLink>
        <NavLink to="/about" className="nav-link">
          About
        </NavLink>
        <NavLink to="/users" className="nav-link">
          Users
        </NavLink>
      </nav>
    </header>
  );
}

export default Navbar;
